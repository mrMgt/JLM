package hello;

import org.springframework.data.annotation.Id;

/**
 * Created by linhnd on 2016/10/18.
 */
public class Demo {
    @Id
    private String id;
}
