package vn.hackathon.likeme.output;

/**
 * Created by linhnd on 2016/10/18.
 */
public class ModelOutput {
    private String resultCode;
    private String errorMessage;

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
