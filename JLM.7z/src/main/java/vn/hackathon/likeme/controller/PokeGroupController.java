package vn.hackathon.likeme.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * Created by linhnd on 2016/10/19.
 */

public class PokeGroupController {
}
